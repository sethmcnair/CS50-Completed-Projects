#include "helpers.h"
#include <math.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    float average;
    float Red;
    float Blue;
    float Green;
    for(int i = 0; i < height; i++)
    {
        for(int j = 0; j < width; j++)
        {
            Red = image[i][j].rgbtRed;
            Blue = image[i][j].rgbtBlue;
            Green = image[i][j].rgbtGreen;
            average = (Red + Blue + Green) / 3;
            if(average > 255)
            {
                average = 255;
            }
            image[i][j].rgbtBlue = round(average);
            image[i][j].rgbtRed = round(average);
            image[i][j].rgbtGreen = round(average);
        }
    }
    return;
}

// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    int newRed;
    int newBlue;
    int newGreen;
    for(int i = 0; i < height; i++)
    {
        for(int j = 0; j < width; j++)
        {
            newRed = round((image[i][j].rgbtRed * 0.393) + (0.769 * image[i][j].rgbtGreen) + (0.189 * image[i][j].rgbtBlue));
            newGreen = round((image[i][j].rgbtRed * 0.349) + (0.686 * image[i][j].rgbtGreen) + (0.168 * image[i][j].rgbtBlue));
            newBlue = round((image[i][j].rgbtRed * 0.272) + (0.534 * image[i][j].rgbtGreen) + (0.131 * image[i][j].rgbtBlue));
            if(newRed > 255)
            {
                newRed = 255;
            }
            if(newBlue > 255)
            {
                newBlue = 255;
            }
            if(newGreen > 255)
            {
                newGreen = 255;
            }
            image[i][j].rgbtBlue = newBlue;
            image[i][j].rgbtRed = newRed;
            image[i][j].rgbtGreen = newGreen;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    for(int i = 0; i < height; i++)
    {
        for(int j = 0; j < width/2; j++)
        {
            RGBTRIPLE temp = image[i][j];
            image[i][j] = image[i][width - (1 + j)];
            image[i][width - (1 + j)] = temp;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    float newGreen;
    float newBlue;
    float newRed;
    for(int i = 0; i < height; i++)
    {
        for(int j = 0; j < width; j++)
        {
            if(i == 0 && j == 0)//TOP LEFT CORNER
            {
                newRed = round((image[i][j].rgbtRed + image[i+1][j+1].rgbtRed + image[i][j+1].rgbtRed + image[i+1][j].rgbtRed) / 4);
                newBlue = round((image[i][j].rgbtBlue + image[i+1][j+1].rgbtBlue + image[i][j+1].rgbtBlue + image[i+1][j].rgbtBlue) / 4);
                newGreen = round((image[i][j].rgbtGreen + image[i+1][j+1].rgbtGreen + image[i][j+1].rgbtGreen + image[i+1][j].rgbtGreen) / 4);
                if(newRed>255)
                {
                    newRed = 255;
                }
                if(newBlue>255)
                {
                    newBlue = 255;
                }
                if(newGreen>255)
                {
                    newGreen = 255;
                }
                image[i][j].rgbtRed = newRed;
                image[i][j].rgbtBlue = newBlue;
                image[i][j].rgbtGreen = newGreen;
            }
            else if(i == 0 && j == (width-1))//TOP RIGHT CORNER
            {
                newRed = round((image[i][j].rgbtRed + image[i+1][j-1].rgbtRed + image[i+1][j].rgbtRed + image[i][j-1].rgbtRed) / 4);
                newBlue = round((image[i][j].rgbtBlue + image[i+1][j-1].rgbtBlue + image[i+1][j].rgbtBlue + image[i][j-1].rgbtBlue) / 4);
                newGreen = round((image[i][j].rgbtGreen + image[i+1][j-1].rgbtGreen + image[i+1][j].rgbtGreen + image[i][j-1].rgbtGreen) / 4);
                if(newRed>255)
                {
                    newRed = 255;
                }
                if(newBlue>255)
                {
                    newBlue = 255;
                }
                if(newGreen>255)
                {
                    newGreen = 255;
                }
                image[i][j].rgbtRed = newRed;
                image[i][j].rgbtBlue = newBlue;
                image[i][j].rgbtGreen = newGreen;
            }
            else if(i == 0)//TOP EDGE
            {
                newRed = round((image[i][j].rgbtRed + image[i+1][j-1].rgbtRed + image[i+1][j].rgbtRed + image[i+1][j+1].rgbtRed + image[i][j-1].rgbtRed + image[i][j+1].rgbtRed) / 6);
                newBlue = round((image[i][j].rgbtBlue + image[i+1][j-1].rgbtBlue + image[i+1][j].rgbtBlue + image[i+1][j+1].rgbtBlue + image[i][j-1].rgbtBlue + image[i][j+1].rgbtBlue) / 6);
                newGreen = round((image[i][j].rgbtGreen + image[i+1][j-1].rgbtGreen + image[i+1][j].rgbtGreen + image[i+1][j+1].rgbtGreen + image[i][j-1].rgbtGreen + image[i][j+1].rgbtGreen) / 6);
                if(newRed>255)
                {
                    newRed = 255;
                }
                if(newBlue>255)
                {
                    newBlue = 255;
                }
                if(newGreen>255)
                {
                    newGreen = 255;
                }
                image[i][j].rgbtRed = newRed;
                image[i][j].rgbtBlue = newBlue;
                image[i][j].rgbtGreen = newGreen;
            }
            else if(j == 0 && i == (height-1))//BOTTOM LEFT CORNER
            {
                newRed = round((image[i][j].rgbtRed + image[i][j+1].rgbtRed + image[i-1][j].rgbtRed + image[i-1][j+1].rgbtRed) / 4);
                newBlue = round((image[i][j].rgbtBlue + image[i][j+1].rgbtBlue + image[i-1][j].rgbtBlue + image[i-1][j+1].rgbtBlue) / 4);
                newGreen = round((image[i][j].rgbtGreen + image[i][j+1].rgbtGreen + image[i-1][j].rgbtGreen + image[i-1][j+1].rgbtGreen) / 4);
                if(newRed>255)
                {
                    newRed = 255;
                }
                if(newBlue>255)
                {
                    newBlue = 255;
                }
                if(newGreen>255)
                {
                    newGreen = 255;
                }
                image[i][j].rgbtRed = newRed;
                image[i][j].rgbtBlue = newBlue;
                image[i][j].rgbtGreen = newGreen;
            }
            else if(j == 0)//LEFT EDGE
            {
                newRed = round((image[i][j].rgbtRed + image[i+1][j].rgbtRed + image[i+1][j+1].rgbtRed  + image[i][j+1].rgbtRed + image[i-1][j].rgbtRed + image[i-1][j+1].rgbtRed) / 6);
                newBlue = round((image[i][j].rgbtBlue + image[i+1][j].rgbtBlue + image[i+1][j+1].rgbtBlue + image[i][j+1].rgbtBlue + image[i-1][j].rgbtBlue + image[i-1][j+1].rgbtBlue) / 6);
                newGreen = round((image[i][j].rgbtGreen + image[i+1][j].rgbtGreen + image[i+1][j+1].rgbtGreen + image[i][j+1].rgbtGreen + image[i-1][j].rgbtGreen + image[i-1][j+1].rgbtGreen) / 6);
                if(newRed>255)
                {
                    newRed = 255;
                }
                if(newBlue>255)
                {
                    newBlue = 255;
                }
                if(newGreen>255)
                {
                    newGreen = 255;
                }
                image[i][j].rgbtRed = newRed;
                image[i][j].rgbtBlue = newBlue;
                image[i][j].rgbtGreen = newGreen;
            }
            else if(j == (width-1))//RIGHT EDGE
            {
                newRed = round((image[i][j].rgbtRed + image[i][j-1].rgbtRed + image[i+1][j-1].rgbtRed + image[i+1][j].rgbtRed + image[i-1][j].rgbtRed + image[i-1][j-1].rgbtRed) / 6);
                newBlue = round((image[i][j].rgbtBlue + image[i][j-1].rgbtBlue + image[i+1][j-1].rgbtBlue + image[i+1][j].rgbtBlue + image[i-1][j].rgbtBlue + image[i-1][j-1].rgbtBlue) / 6);
                newGreen = round((image[i][j].rgbtGreen + image[i][j-1].rgbtGreen + image[i+1][j-1].rgbtGreen + image[i+1][j].rgbtGreen + image[i-1][j].rgbtGreen + image[i-1][j-1].rgbtGreen) / 6);
                if(newRed>255)
                {
                    newRed = 255;
                }
                if(newBlue>255)
                {
                    newBlue = 255;
                }
                if(newGreen>255)
                {
                    newGreen = 255;
                }
                image[i][j].rgbtRed = newRed;
                image[i][j].rgbtBlue = newBlue;
                image[i][j].rgbtGreen = newGreen;
            }
            else if(i == (height-1) && j == (width-1))//BOTTOM RIGHT CORNER
            {
                newRed = round((image[i][j].rgbtRed + image[i-1][j].rgbtRed + image[i][j-1].rgbtRed + image[i-1][j-1].rgbtRed) / 4);
                newBlue = round((image[i][j].rgbtBlue + image[i-1][j].rgbtBlue + image[i][j-1].rgbtBlue + image[i-1][j-1].rgbtBlue) / 4);
                newGreen = round((image[i][j].rgbtGreen + image[i-1][j].rgbtGreen + image[i][j-1].rgbtGreen + image[i-1][j-1].rgbtGreen) / 4);
                if(newRed>255)
                {
                    newRed = 255;
                }
                if(newBlue>255)
                {
                    newBlue = 255;
                }
                if(newGreen>255)
                {
                    newGreen = 255;
                }
                image[i][j].rgbtRed = newRed;
                image[i][j].rgbtBlue = newBlue;
                image[i][j].rgbtGreen = newGreen;
            }
            else if(i == height-1)//BOTTOM EDGE
            {
                newRed = round((image[i][j].rgbtRed + image[i-1][j].rgbtRed + image[i-1][j+1].rgbtRed  + image[i][j+1].rgbtRed + image[i][j-1].rgbtRed + image[i-1][j-1].rgbtRed) / 6);
                newBlue = round((image[i][j].rgbtBlue + image[i-1][j].rgbtBlue + image[i-1][j+1].rgbtBlue + image[i][j+1].rgbtBlue + image[i][j-1].rgbtBlue + image[i-1][j-1].rgbtBlue) / 6);
                newGreen = round((image[i][j].rgbtGreen + image[i-1][j].rgbtGreen + image[i-1][j+1].rgbtGreen + image[i][j+1].rgbtGreen + image[i][j-1].rgbtGreen + image[i-1][j-1].rgbtGreen) / 6);
                if(newRed>255)
                {
                    newRed = 255;
                }
                if(newBlue>255)
                {
                    newBlue = 255;
                }
                if(newGreen>255)
                {
                    newGreen = 255;
                }
                image[i][j].rgbtRed = newRed;
                image[i][j].rgbtBlue = newBlue;
                image[i][j].rgbtGreen = newGreen;
            }
            else
            {
                newRed = round((image[i][j].rgbtRed + image[i+1][j-1].rgbtRed + image[i+1][j].rgbtRed + image[i+1][j+1].rgbtRed + image[i][j-1].rgbtRed + image[i][j+1].rgbtRed + image[i-1][j-1].rgbtRed + image[i-1][j].rgbtRed + image[i-1][j+1].rgbtRed) / 9);
                newBlue = round((image[i][j].rgbtBlue + image[i+1][j-1].rgbtBlue + image[i+1][j].rgbtBlue + image[i+1][j+1].rgbtBlue + image[i][j-1].rgbtBlue + image[i][j+1].rgbtBlue + image[i-1][j-1].rgbtBlue + image[i-1][j].rgbtBlue + image[i-1][j+1].rgbtBlue) / 9);
                newGreen = round((image[i][j].rgbtGreen + image[i+1][j-1].rgbtGreen + image[i+1][j].rgbtGreen + image[i+1][j+1].rgbtGreen + image[i][j-1].rgbtGreen + image[i][j+1].rgbtGreen + image[i-1][j-1].rgbtGreen + image[i-1][j].rgbtGreen + image[i-1][j+1].rgbtGreen) / 9);
                if(newRed>255)
                {
                    newRed = 255;
                }
                if(newBlue>255)
                {
                    newBlue = 255;
                }
                if(newGreen>255)
                {
                    newGreen = 255;
                }
                image[i][j].rgbtRed = newRed;
                image[i][j].rgbtBlue = newBlue;
                image[i][j].rgbtGreen = newGreen;
            }
        }
    }
    return;
}
